# 关于
整合SSM框架（SpringMVC + Spring + MyBatis），适合刚接触spring的童鞋，需要有servlet和jsp基础。学习完SSM整合后可以应付开发工作，但是建议继续深究，学习spring boot，spring cloud等技术，让开发效率更上一层楼。

# 博客
http://blog.csdn.net/qq598535550/article/details/51703190

# 环境
- jdk 1.8
- tomcat 8.5

![](https://img-ask.csdn.net/upload/201806/05/1528204838_152827.png)
